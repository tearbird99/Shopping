const button = document.querySelectorAll('.tab-button');
const content = document.querySelectorAll('.tab-content');

//for (let i = 0; i < 3; i++){
//    button[i].addEventListener('click', function(){
//        탭열기(i);
//    });
//}

document.querySelector('.list').addEventListener('click', function(e){
    탭열기(Number(e.target.dataset.id));
});

function 탭열기(num){
    button.forEach(element => element.classList.remove('orange'));
    content.forEach(element => element.classList.remove('show'));
    button[num].classList.add('orange');
    content[num].classList.add('show');
}